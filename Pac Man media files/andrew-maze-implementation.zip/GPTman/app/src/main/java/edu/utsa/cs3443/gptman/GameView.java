package edu.utsa.cs3443.gptman;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.os.Handler;
import android.util.AttributeSet;
import android.view.View;

import java.util.LinkedList;
import java.util.Queue;

public class GameView extends View {
    final int levelData[][] = {
            {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            {0, 3, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 3, 0},
            {0, 1, 0, 0, 1, 0, 0, 0, 1, 0, 1, 0, 0, 0, 1, 0, 0, 1, 0},
            {0, 1, 0, 0, 1, 0, 0, 0, 1, 0, 1, 0, 0, 0, 1, 0, 0, 1, 0},
            {0, 1, 1, 1, 1, 1, 1, 1, 1, 3, 1, 1, 1, 1, 1, 1, 1, 1, 0},
            {0, 1, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 1, 0},
            {0, 1, 1, 1, 1, 0, 1, 1, 2, 0, 2, 1, 1, 0, 1, 1, 1, 1, 0},
            {0, 0, 0, 0, 0, 0, 0, 0, 2, 2, 2, 0, 0, 0, 0, 0, 0, 0, 0},
            {0, 1, 1, 1, 1, 0, 1, 1, 2, 0, 2, 1, 1, 0, 1, 1, 1, 1, 0},
            {0, 1, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 1, 0},
            {0, 1, 1, 1, 1, 1, 1, 1, 1, 3, 1, 1, 1, 1, 1, 1, 1, 1, 0},
            {0, 1, 0, 0, 1, 0, 0, 0, 1, 0, 1, 0, 0, 0, 1, 0, 0, 1, 0},
            {0, 1, 0, 0, 1, 0, 0, 0, 1, 0, 1, 0, 0, 0, 1, 0, 0, 1, 0},
            {0, 3, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 3, 0},
            {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}
    };

    private float pacmanOffsetX = 0, pacmanOffsetY = 0;
    private float ghostOffsetX = 0, ghostOffsetY = 0;
    private final float moveSpeed = 0.1f;
    private boolean pacmanMoving = false, ghostMoving = false;
    private float pacmanFloatX = 1, pacmanFloatY = 1;
    private float ghostFloatX = 13, ghostFloatY = 18;
    private final float speed = 0.1f;
    private int pacmanX = 1, pacmanY = 1;
    private int ghostX = 17, ghostY = 13;
    private int directionX = 0, directionY = 0;

    private Paint wallPaint, pelletPaint, powerPelletPaint, pacmanPaint, ghostPaint;
    private Handler gameHandler = new Handler();
    private Runnable gameRunnable;
    private Bitmap pacmanBitmap, ghostBitmap;

    private void loadBitmaps() {
        pacmanBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.temppacman);
        ghostBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.ghost);
    }

    public GameView(Context context, AttributeSet attrs) {
        super(context, attrs);
        initializePaints();
        loadBitmaps();
        startGameLoop();
    }

    private void initializePaints() {
        wallPaint = new Paint();
        wallPaint.setColor(Color.BLUE);

        pelletPaint = new Paint();
        pelletPaint.setColor(Color.YELLOW);

        powerPelletPaint = new Paint();
        powerPelletPaint.setColor(Color.RED);
    }

    private void startGameLoop() {
        gameRunnable = new Runnable() {
            @Override
            public void run() {
                updateGame();
                invalidate(); // Redraw the view
                gameHandler.postDelayed(this, 200); // ~60 FPS
            }
        };
        gameHandler.post(gameRunnable);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        int tileSize = Math.min(getWidth() / levelData[0].length, getHeight() / levelData.length);
        Paint paint = new Paint();

        canvas.drawColor(Color.BLACK);

        // Draw the grid
        for (int row = 0; row < levelData.length; row++) {
            for (int col = 0; col < levelData[row].length; col++) {
                switch (levelData[row][col]) {
                    case 0: // Wall
                        paint.setColor(Color.BLUE);
                        canvas.drawRect(col * tileSize, row * tileSize,
                                (col + 1) * tileSize, (row + 1) * tileSize, paint);
                        break;
                    case 1: // Pellet
                        paint.setColor(Color.YELLOW);
                        canvas.drawCircle((col + 0.5f) * tileSize, (row + 0.5f) * tileSize,
                                tileSize / 6, paint);
                        break;
                    case 3: // Power Pellet
                        paint.setColor(Color.RED);
                        canvas.drawCircle((col + 0.5f) * tileSize, (row + 0.5f) * tileSize,
                                tileSize / 4, paint);
                        break;
                }
            }
        }

        // Draw Pac-Man
        if (pacmanBitmap != null) {
            canvas.drawBitmap(
                    pacmanBitmap,
                    null,
                    new Rect(
                            (int) ((pacmanX + pacmanOffsetX) * tileSize),
                            (int) ((pacmanY + pacmanOffsetY) * tileSize),
                            (int) ((pacmanX + pacmanOffsetX + 1) * tileSize),
                            (int) ((pacmanY + pacmanOffsetY + 1) * tileSize)
                    ),
                    paint
            );
        }

        // Draw Ghost
        if (ghostBitmap != null) {
            canvas.drawBitmap(
                    ghostBitmap,
                    null,
                    new Rect(
                            (int) ((ghostX + ghostOffsetX) * tileSize),
                            (int) ((ghostY + ghostOffsetY) * tileSize),
                            (int) ((ghostX + ghostOffsetX + 1) * tileSize),
                            (int) ((ghostY + ghostOffsetY + 1) * tileSize)
                    ),
                    paint
            );
        }
    }


    private boolean pacmanMoved = false;
    private int lastPacmanX = pacmanX, lastPacmanY = pacmanY;

    private void updateGame() {
        // Check if Pac-Man has moved
        boolean hasPacmanMoved = (pacmanX != lastPacmanX || pacmanY != lastPacmanY);
        if (hasPacmanMoved) {
            pacmanMoved = true; // Mark that Pac-Man has moved
        }

        // Move Pac-Man if the next position is valid
        if (canMove(pacmanX + directionX, pacmanY + directionY)) {
            pacmanX += directionX;
            pacmanY += directionY;

            // Collect pellets
            if (levelData[pacmanY][pacmanX] == 1) {
                levelData[pacmanY][pacmanX] = 2; // Clear pellet
            } else if (levelData[pacmanY][pacmanX] == 3) {
                levelData[pacmanY][pacmanX] = 2; // Clear power pellet
            }
        }

        // Move the ghost if Pac-Man has moved
        if (pacmanMoved) {
            int[] ghostDirection = getGhostDirection();
            if (ghostDirection != null && canMove(ghostX + ghostDirection[0], ghostY + ghostDirection[1])) {
                ghostX += ghostDirection[0];
                ghostY += ghostDirection[1];
                ghostMoving = true; // Indicate the ghost is moving
            }
        }

        // Update the last known Pac-Man position
        lastPacmanX = pacmanX;
        lastPacmanY = pacmanY;

    }

    private boolean canMove(int x, int y) {
        return x >= 0 && y >= 0 && x < levelData[0].length && y < levelData.length && levelData[y][x] != 0; // Not a wall
    }

    private int[] getGhostDirection() {
        // Perform BFS to find the shortest path to Pac-Man
        boolean[][] visited = new boolean[levelData.length][levelData[0].length];
        Queue<int[]> queue = new LinkedList<>();
        int[][] directions = {{0, 1}, {1, 0}, {0, -1}, {-1, 0}}; // right, down, left, up
        int[][] parent = new int[levelData.length][levelData[0].length];

        for (int i = 0; i < levelData.length; i++) {
            for (int j = 0; j < levelData[0].length; j++) {
                parent[i][j] = -1; // No parent initially
            }
        }

        queue.add(new int[]{ghostX, ghostY});
        visited[ghostY][ghostX] = true;

        while (!queue.isEmpty()) {
            int[] current = queue.poll();
            int x = current[0];
            int y = current[1];

            if (x == pacmanX && y == pacmanY) {
                // Backtrack to find the direction from ghost to pacman
                int px = pacmanX;
                int py = pacmanY;

                while (parent[py][px] != -1) {
                    int parentValue = parent[py][px];
                    int pxParent = parentValue % levelData[0].length;
                    int pyParent = parentValue / levelData[0].length;

                    if (pxParent == ghostX && pyParent == ghostY) {
                        return new int[]{px - ghostX, py - ghostY};
                    }

                    px = pxParent;
                    py = pyParent;
                }
            }

            // Explore the neighbors
            for (int[] dir : directions) {
                int nx = x + dir[0];
                int ny = y + dir[1];

                if (canMove(nx, ny) && !visited[ny][nx]) {
                    visited[ny][nx] = true;
                    queue.add(new int[]{nx, ny});
                    parent[ny][nx] = y * levelData[0].length + x;
                }
            }
        }

        return null; // No path found
    }


    public void setDirection(int dx, int dy) {
        directionX = dx;
        directionY = dy;
    }

}
