package edu.utsa.cs3443.gptman;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private GameView gameView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        gameView = findViewById(R.id.gameView);

        findViewById(R.id.upButton).setOnClickListener(view -> gameView.setDirection(0, -1));
        findViewById(R.id.downButton).setOnClickListener(view -> gameView.setDirection(0, 1));
        findViewById(R.id.leftButton).setOnClickListener(view -> gameView.setDirection(-1, 0));
        findViewById(R.id.rightButton).setOnClickListener(view -> gameView.setDirection(1, 0));
    }
}
